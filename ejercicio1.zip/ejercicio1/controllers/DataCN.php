<?php

class DataCN {

	const server = "localhost";
	const user = "root";
	const password = "";
	const database = "clientes_creantis";

}

?>