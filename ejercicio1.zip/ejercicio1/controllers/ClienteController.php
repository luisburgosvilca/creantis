<?php

class ClienteController{

    public function RegistrarCliente()
    {

       $data['dni']       = $_POST['dni'];
       $data['nombre']    = $_POST['nombre'];
       $data['apellido']  = $_POST['apellido'];
       $data['email']     = $_POST['email'];
       $data['direccion'] = $_POST['direccion'];

       include_once('models/ClienteModel.php');
       $ClienteModel = new ClienteModel();

       if($ClienteModel -> RegistrarCliente($data)){
        //echo 1;

        $this->MostrarClientes();

       }
       else{
           echo "Hubo un error";
       }

    }

    public function EliminarCliente()
    {
        $data['cliente_id'] = $_POST['cliente_id'];

        include_once('models/ClienteModel.php');
        $ClienteModel = new ClienteModel();
        $ClienteModel -> EliminarCliente($data);

        $this->MostrarClientes();

    }

    public function MostrarClientes()
    {
        include_once('models/ClienteModel.php');
        $ClienteModel = new ClienteModel();
        $clientes = $ClienteModel -> getClientes();

        //echo "Hola";

        include_once('views/partials/ClientesPartial.php');
        $ClientesPartial = new ClientesPartial();
        $ClientesPartial -> MostrarClientesPartial($clientes);

    }

}

?>