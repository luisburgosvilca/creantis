<?php

class GraficoPartial
{
    public function MostrarGrafico()
    {

        $numero = $_POST['numero'];
        for ( $i=0; $i < $numero ;$i++){
            for ($j=0;  $j<$numero;$j++){

                $dibujo[$i][$j] = "_";
                $dibujo[$i][$i] = "X";
                $dibujo[$i][$numero - $i - 1] = "X";
            }
        }

        ?>
        <section class="center">
        <?php
        for ( $i=0; $i < $numero ;$i++){
            echo "<p>";
            for ($j=0;  $j<$numero;$j++){
            echo $dibujo[$i][$j];
            }
            echo "</p>";
        }                            
        
        ?>

        </section>

        <?php

    }
}

?>