<?php

// $numero = 5;
// $i = 1;



// var_dump($grafico);

// for($i = 1; $i<=$numero; $i++){
//     echo "X";
// }

include_once('controllers/MainController.php');
$MainController = new MainController();
$MainController -> MainControllerIndex();

?>