<?php

  include_once('controllers/MainController.php');
  $MainController = new MainController();
  $MainController -> ClientesController();

?>